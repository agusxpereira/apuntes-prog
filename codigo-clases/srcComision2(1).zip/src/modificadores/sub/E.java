package modificadores.sub;

import modificadores.A;

public class E extends A {
    
	public E() {
		//privado = 3;
	    protegido = 5;
	   // friendly = 5;
	    publico = 5;
	}
}
