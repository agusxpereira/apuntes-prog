package modificadores.sub;

import modificadores.A;

public class D{

	public D() {
		A a1 = new A();
		//a1.privado=3;
		a1.publico=4;
		//a1.friendly=4;
		//a1.protegido=4;
	}
}
