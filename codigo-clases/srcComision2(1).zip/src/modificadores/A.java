package modificadores;

public  class A {

	public int publico;
	protected int protegido;
	int friendly;
	private int privado;
}
