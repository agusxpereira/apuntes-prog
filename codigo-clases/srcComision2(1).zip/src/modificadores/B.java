package modificadores;

public class B {

	public B() {
		A a1 = new A();
		//a1.privado=3;
		a1.publico=4;
		a1.friendly=4;
		a1.protegido=4;
	}
}
