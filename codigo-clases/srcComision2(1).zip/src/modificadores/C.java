package modificadores;

public class C extends A {

	public C() {
		//privado = 3;
	    protegido = 5;
	    friendly = 5;
	    publico = 5;
	}
}
