
public abstract class Condicion {

	public abstract boolean cumple(Vendedor vv);
}
